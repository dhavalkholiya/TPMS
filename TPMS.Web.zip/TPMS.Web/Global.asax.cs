﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using ErrorLogFramework.Web.Model;
using System.Globalization;
using ErrorLogFramework.Web.Common;
using ErrorLogFramework.Web.BAL;


namespace TPMS.Web
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            BundleTable.EnableOptimizations = true;
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            try
            {
                var er = Server.GetLastError();
                
                ErrorLogModel errorLogModel;
                ErrorLogBAL errorLogBal = new ErrorLogBAL();
                List<ErrorLogInsertViewModel> errorLogInsertViewModel;

                errorLogModel = SetErrorLogModel(er);
                errorLogInsertViewModel = errorLogBal.SaveErrorLog(errorLogModel);
                if (errorLogInsertViewModel.Count > 0)
                {                    
                    Response.Redirect("~/Error/Index/" + errorLogInsertViewModel[0].ErrorLogID + "?e=" + errorLogInsertViewModel[0].ErrorGUID);
                    // SET error page URL with the querystring for errorlogid and errorlog GUID value
                }
                else
                {
                    Response.Redirect("~/Error/Index/0");
                    // SET error page URL with the querystring for errorlogid as 0 in case no error is logged for the current exception
                }
            }
            catch (Exception )
            {
                Response.Redirect("~/Error/Index/-1");
                // SET error page URL with the querystring for errorlogid as -1 in case any exception occures while errorlogging
            }
        }
        private ErrorLogModel SetErrorLogModel(Exception er)
        {
            ErrorLogModel errorLogModel = new ErrorLogModel();
            errorLogModel.ErrorURL = Request.Url.ToString();
            errorLogModel.ErrorMessage = er.Message;
            errorLogModel.InnerException = er.InnerException != null ? er.InnerException.Message : null;
            errorLogModel.StackTrace = er.StackTrace;
            errorLogModel.TargetSite = er.TargetSite.ToString();
            errorLogModel.ErrorSource = er.Source;
            errorLogModel.BrowserDetails = Request.Browser.Browser + " Version: " +
                   Request.Browser.Version;
            errorLogModel.CookiesDetails = Request.Browser.Cookies.ToString(CultureInfo.InvariantCulture);
            errorLogModel.IPAddress = System.Web.HttpContext.Current.Request.UserHostAddress; ;
            errorLogModel.UserSession = HttpContext.Current.Session != null ? HttpContext.Current.Session[SessionKeys.UserSessionId] != null ? HttpContext.Current.Session["UserID"].ToString() : null : null;
            // Replace your current user session name in SessionKeys class with appropriate session name.

            return errorLogModel;
        }

    }

}
