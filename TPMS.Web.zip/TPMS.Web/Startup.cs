﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(TPMS.Web.Startup))]
namespace TPMS.Web
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
