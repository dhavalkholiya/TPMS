﻿using System.Web;
using System.Web.Optimization;

namespace TPMS.Web
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js",
                        "~/Scripts/jquery.unobtrusive-ajax.js"                        
                        ));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.validate*"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                      "~/Scripts/bootstrap.js",
                      "~/Scripts/bootstrap-datepicker.js",
                      "~/Scripts/respond.js"));

            bundles.Add(new ScriptBundle("~/bundles/CustomScript").Include(
                      "~/Scripts/User.js"
                      ));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                    "~/Content/datepicker.css",
                      "~/Content/bootstrap.css",
                      "~/Content/bootstrap.min.css",
                      "~/Content/sb-admin.css"
                      ));

            bundles.Add(new StyleBundle("~/fonts/myfontawesome").Include(
                "~/fonts/font-awesome/css/font-awesome.min.css"
                ));

            bundles.Add(new StyleBundle("~/Content/CustomCss").Include(
                "~/Content/Mycss.css"
                            ));
            bundles.Add(new StyleBundle("~/Content/UserJQGridStyle").Include(
                        "~/Content/JqGrid/ui.jqgrid-bootstrap.css",
                        "~/Content/JqGrid/ui.jqgrid.css",
                        "~/Content/JqGrid/jquery-ui.css"
                            ));

            bundles.Add(new ScriptBundle("~/bundles/JQGridScript").Include(
                        "~/Scripts/JqGrid/jquery.jqGrid.js",
                        "~/Scripts/JqGrid/grid.locale-en.js",
                        "~/Scripts/JqGrid/jqModal.js",
                        "~/Scripts/JqGrid/jqDnR.js"                        
                     ));

            bundles.Add(new ScriptBundle("~/bundles/UserJQGridScript").Include(                       
                       "~/Scripts/UserJQGridList.js"
                    ));

            bundles.Add(new ScriptBundle("~/bundles/ProjectReportJQGridScript").Include(
                      "~/Scripts/ProjectReportJqGrid.js"
                   ));

            bundles.Add(new ScriptBundle("~/bundles/EmployeeListAssignProject").Include(
                      "~/Scripts/AssignedProjectJqGrid.js"
                   ));

            bundles.Add(new ScriptBundle("~/bundles/CustomEmployeeMapping").Include(
                      "~/Scripts/CustomEmployeeMapping.js"
                   ));

            bundles.Add(new ScriptBundle("~/bundles/CommonScript").Include(
                     "~/Scripts/CustomEmployeeMapping.js"
                  ));


        }
    }
}
