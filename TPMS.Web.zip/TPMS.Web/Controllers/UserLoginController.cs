﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TPMS.Model;
using TPMS.BAL;
using ErrorLogFramework.Web.Common;

namespace TPMS.Web.Controllers
{
    public class UserLoginController : Controller
    {

        #region Declaration
        UserLoginBAL userLoginBal = new UserLoginBAL();
        #endregion
        //
        // GET: /UserLogin/
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult IsLoginValidate(UserLoginModel userData)
        {
            int result;
            try
            {
                result = userLoginBal.ValidateUserLogin(userData);
                if (result > 0)
                {
                    Session["User"] = userData.EmailId;
                    Session["UserType"] = userData.EmployeeType;
                    TempData["Sucess"] = "Login Sucess";
                    return RedirectToAction("Index", "Employee");
                }
                else
                {
                    TempData["Failure"] = "Login Fail or You Are Not Authorize";
                }
            }
            catch (Exception )
            {
                throw;                
            }
            //return View("Index", "Employee");
            return RedirectToAction("Index", "UserLogin");
            
        }

        [HttpGet]
        public ActionResult LogOff()
        {
            Session.Remove("User");
            Session.Remove("UserType");            
            HttpContext.Session.RemoveAll();

            return RedirectToAction("Index", "UserLogin");
        }
	}
}