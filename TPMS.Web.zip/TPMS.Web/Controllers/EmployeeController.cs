﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TPMS.Model;
using System.Configuration;
using Newtonsoft.Json;
using System.Web.Script.Serialization;
//using TPMS.DAL;
using TPMS.BAL;
using TPMS.Common;
using Forms.Controllers;
using MessageFramework;

namespace TPMS.Web.Controllers
{
    [Authority("Admin")]
    public class EmployeeController : Controller
    {
        #region Declaration
        public static string ConnectionString = ConnectionDB.DBConn;
        EmployeeBAL employeeBal = new EmployeeBAL();
        EmployeeCommon employeeCommon = new EmployeeCommon();
        List<MessageFramework.Model.MessageModel> messageModel;
        #endregion

        //
        // GET: /Employee/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Register()
        {
            try
            {
                ViewBag.EmployeeType = employeeCommon.GetEmployeeType();
                ViewBag.bloodGroup = employeeCommon.GetBloodGroup();
                ViewBag.EmpStatus = employeeCommon.GetEmployeeStatus();
                ViewBag.Country = employeeBal.GetCountry();
            }
            catch (Exception)
            {
                throw;
            }
            return View();
        }

        public ActionResult Reports()
        {
            return View();
        }

        #region Employee Registration
        [HttpPost]
        public ActionResult Register(EmployeeModel employeeModel, HttpPostedFileBase uplodedImage)
        {
            try
            {
                #region UploadFile
                bool isuploaded = false;
                if (uplodedImage != null && uplodedImage.ContentLength > 0)
                {
                    string pic = System.IO.Path.GetFileName(uplodedImage.FileName);
                    string path = System.IO.Path.Combine(Server.MapPath("~/Content/Upload/Images/"), pic);
                    uplodedImage.SaveAs(path);
                    isuploaded = true;
                }
                #endregion
                #region Register Employee
                if (isuploaded == true)
                {
                    employeeModel.PhotoName = uplodedImage.FileName;
                    int result = employeeBal.AddEmployee(employeeModel);
                    if (result > 0)
                    {
                        //TempData["Success"] = "Register Successfully!";
                        messageModel = MessageFramework.Message.GetMessage("InsertSucess");
                        if (messageModel.Count > 0)
                            TempData["Success"] = messageModel[0].MessageText;
                    }
                    else
                    {
                        TempData["Success"] = null;
                    }
                }
                #endregion

            }
            catch (Exception)
            { throw; }

            return View("Index");
        }
        #endregion

        #region Display Employee List
        public ActionResult DisplayEmployeeList()
        {
            ViewBag.ProjectList = employeeBal.GetProjectlist(0);
            return View();
        }
        #endregion
        public ActionResult UserLogin()
        {
            return View();
        }

        #region GetUserGrid for Jqgrid
        public string GetUsers(string Search, int page, int rows, string sidx, string sord)
        {
            Search = string.IsNullOrEmpty(Search) ? "" : Search.Trim();
            int noOfRecords = 0;
            var lstEmployeeModel = employeeBal.FilterGridList(Search, sidx, sord, out noOfRecords, page, rows);
            var gridUser = new
            {
                total = Convert.ToInt32(Math.Ceiling(Convert.ToDecimal(noOfRecords) / Convert.ToDecimal(rows))),
                page = page,
                records = noOfRecords,
                rows = lstEmployeeModel,
            };
            var jsonSerializer = new JavaScriptSerializer();
            return jsonSerializer.Serialize(gridUser);
        }
        #endregion

        #region AssignProject TO Employee

        [HttpPost]
        public ActionResult EmployeeProjectMapping(ProjectEmployeeMappingModel projectEmployeeMappingModel)
        {
            int result = 0;

            try
            {
                result = employeeBal.ProjectEmployeeMapping(projectEmployeeMappingModel);

                if (result > 0)
                {

                    return Json(new { sucess = true });
                }
                else
                {

                    return Json(new { sucess = false });
                }
            }
            catch (Exception)
            {
                throw;
            }
            //return Json(new { sucess = false});
        }
        #endregion

        #region GetPopUPModelData
        public JsonResult GetPopUpData(int id)
        {
            try
            {
                List<EmployeeModel> PopupData = new List<EmployeeModel>();
                ViewBag.ProjectList = null;
                ViewBag.ProjectList = employeeBal.GetProjectlist(id);
                PopupData = employeeBal.GetPopUpData(id);
                return Json(PopupData, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region GetProjectListById
        public string GetProjectListById(string Search, int page, int rows, string sidx, string sord)
        {
            Search = string.IsNullOrEmpty(Search) ? "0" : Search.Trim();
            int noOfRecords = 0;
            var lstEmployeeModel = employeeBal.GetProjectListById(Convert.ToInt16(Search));
            var gridUser = new
            {
                total = Convert.ToInt32(Math.Ceiling(Convert.ToDecimal(noOfRecords) / Convert.ToDecimal(rows))),
                page = page,
                records = noOfRecords,
                rows = lstEmployeeModel,
            };
            var jsonSerializer = new JavaScriptSerializer();
            return jsonSerializer.Serialize(gridUser);
        }
        #endregion

        #region GetJsonStateData
        public JsonResult GetState(string countryName)
        {
            List<SelectListItem> StateList = new List<SelectListItem>();
            try
            {

                StateList = employeeBal.GetState(countryName);
            }
            catch (Exception)
            {
                throw;
            }
            return Json(JsonConvert.SerializeObject(StateList));
        }
        #endregion

        #region GetJsonCityData
        public JsonResult GetCity(string StateName)
        {
            List<SelectListItem> CityList = new List<SelectListItem>();
            try
            {
                CityList = employeeBal.GetCity(StateName);
            }
            catch (Exception)
            {
                throw;
            }
            return Json(JsonConvert.SerializeObject(CityList));
        }
        #endregion

        #region Remote Function for Date validation
        public ActionResult DateDifferenceCheck(String startdate, String enddate)
        {
            if (Convert.ToDateTime(startdate) > Convert.ToDateTime(enddate))
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
            return Json(true, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Get Project Report list for Jqgrid
        public string GetInCompletedProjectList(string StartDate, string Enddate, int page, int rows, string sidx, string sord)
        {
            //Search = string.IsNullOrEmpty(Search) ? "" : Search.Trim();
            int noOfRecords = 0;
            var lstEmployeeModel = employeeBal.GetInCompletedProjectList(StartDate, Enddate);
            var gridUser = new
            {
                total = Convert.ToInt32(Math.Ceiling(Convert.ToDecimal(noOfRecords) / Convert.ToDecimal(rows))),
                page = page,
                records = noOfRecords,
                rows = lstEmployeeModel,
            };
            var jsonSerializer = new JavaScriptSerializer();
            return jsonSerializer.Serialize(gridUser);
        }
        #endregion

        #region Remote Function for Already Assign project Date Period
        public ActionResult CheckDateValidation(ProjectEmployeeMappingModel projectEmployeeMappingModel)
        {
            try
            {
                string Result = employeeBal.CheckDateValidation(projectEmployeeMappingModel);
                if (Result == "N")
                {
                    return Json("You Have Already Assigned Project in Given Date", JsonRequestBehavior.AllowGet);
                }
                if (Convert.ToDateTime(projectEmployeeMappingModel.StartDate) >= Convert.ToDateTime(projectEmployeeMappingModel.EndDate) && projectEmployeeMappingModel.EndDate != null)
                {
                    return Json("End Date Must gratter then Start Date ", JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return Json(true, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Remote Function for Check if EmailId is Already Exist Or not
        public ActionResult ValidateEmailId(String EmailId)
        {
            try
            {
                int Result = employeeBal.ValidateEmailId(EmailId);

                if (Result > 0)
                {
                    return Json("Email Id Already Exist", JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return Json(true, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Remote Function for Validate BirthDate
        public ActionResult ValidateBirthDate(String BirthDate)
        {
            try
            {
                DateTime date = Convert.ToDateTime(BirthDate);
                int birthYear = date.Year;
                int currentYear = DateTime.Now.Year;
                int result = currentYear - birthYear;
                if (result <= 18)
                {
                    return Json("You Must Have To be Atleast 18 Year Old", JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return Json(true, JsonRequestBehavior.AllowGet);
        }
        #endregion


    }
}