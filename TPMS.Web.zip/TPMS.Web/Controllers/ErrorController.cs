﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ErrorLogFramework.Web.Controllers
{
    public class ErrorController : Controller
    {
        //
        // GET: /Error/

        public ActionResult Index(int id = 0, string e = "")
        {
            //List<MessageFramework.Model.MessageModel> messageModel;

            //messageModel = MessageFramework.Message.GetMessage("ErrorMessage");
            //if (messageModel.Count > 0)
            //    ViewBag.Error = messageModel[0].MessageText + " : " + id.ToString() + ":" + e;
            return View();
        }

    }
}
