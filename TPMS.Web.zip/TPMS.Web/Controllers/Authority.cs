﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Forms.Controllers
{
    /*CustomAuth*/
    public class Authority : AuthorizeAttribute
    {
        string[] AllowedRoles = { "Admin", "Team Leader","Project Manager" };
        string[] AssigendRole;
        public Authority()
        {}        
        public Authority(params string[] roles)
        {
            this.AssigendRole = roles;
        }

        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            bool authorize = false;
            var role="";
            if (httpContext.Session["UserType"] != null)
            {
                //return authorize;            
                role = httpContext.Session["UserType"].ToString();
                foreach (var UserRole in AllowedRoles)
                {
                    if (UserRole == role)
                    {
                        authorize = true;
                        break;
                    }
                }
            }            

            return authorize;
        }        
        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            filterContext.Result = new HttpUnauthorizedResult();
        }
    }
}