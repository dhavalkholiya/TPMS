﻿$(document).ready(function () {

  
    $("#AssignProject").jqGrid({
        colNames: ['Project Title', 'Description', 'Start Date', 'End Date',  'Status'],
        colModel: [
            {
                name: 'ProjectTitle',
                index: 'ProjectTitle',
                sortable: true,
                align: 'Center',               
                editable: true,
                edittype: 'text',
                search: false
            },
            {
                name: 'Description',
                index: 'Description',
                sortable: true,
                align: 'Center',               
                editable: true,
                edittype: 'text',
                search: false
            },
            {
                name: 'StartDate',
                index: 'StartDate',
                sortable: true,
                align: 'Center',                
                editable: true,
                edittype: 'text',
                search: false,
                formatter: 'date', formatoptions: { srcformat: 'd/m/Y', newformat: 'd/m/Y' }
            },
            {
                name: 'EndDate',
                index: 'EndDate',
                sortable: true,
                align: 'Center',              
                editable: true,
                edittype: 'text',
                search: false,
                formatter: 'date',formatoptions: { srcformat: 'd/m/Y', newformat: 'd/m/Y'}
            },            
            {
                name: 'Status',
                sortable: true,
                align: 'Center',               
                editable: true,
                edittype: 'text',
                search: false
            },
        ],
        pager: true,
        viewrecords: true,
        sortname: 'ProjectTitle',
        sortorder: "Asc",
        height: 'auto',
        viewrecords: true,
        rownumbers: true,
        caption: 'Assigned Projects',
        url: '/Employee/GetProjectListById',
        datatype: 'json',
        mtype: 'get',
        autowidth:true,
        rowNum: 10,
        loadonce: false,
        rowList: [2, 5, 10, 15],
        pager: '#userPagination',        
        autowidth: true,
        shrinkToFit: true,
        search: true
    });

});
