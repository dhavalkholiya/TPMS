﻿$(document).ready(function () {

    $("#filtergrid").click(function () {
        filterGrid();
    });
    
    function filterGrid() {
        var postDataValues = $("#userGrids").jqGrid('getGridParam', 'postData');
        postDataValues['Search'] = $("#searchvalue").val();

        $("#userGrids").jqGrid().setGridParam({ postData: postDataValues, page: 1 }).trigger('reloadGrid');
    }


    function ProjectGrid() {
        var postDataValues = $("#AssignProject").jqGrid('getGridParam', 'postData');
        postDataValues['Search'] = $("#userdata").val();
        $("#AssignProject").jqGrid().setGridParam({ postData: postDataValues, page: 1 }).trigger('reloadGrid');
    }

    $('#closeModelBtn').click(function () {
     //   alert("close");
        $('#Sucess-msg').empty();
        $('#Fail-msg').empty();
    });

    //function OpenPopUpDialog(Id) {
    //    alert("hello" + Id);
    //    var paramurl = '/Employee/GetPopUpData/' + Id;
    //    $.ajax({
    //        url: paramurl,
    //        success: function (result) {
    //            alert(result);
    //            $("#userdata").html(result);
    //            $("#myModal").modal({ keyboard: true, show: 'true' });
    //        }
    //    });
    //    return false;
    //}

    $('body').on("click", ".assignlink", function () {
        var Id = $(this).attr("href");
        //alert("hello " + Id);
     
        var paramurl = '/Employee/GetPopUpData/' + Id;
        $.ajax({
            url: paramurl,
            success: function (result) {                
                $.each(result, function (index, row) {
                    console.log(row.EmployeeType);
                });
                
                $("#Empname").html(result[0].FirstName);
                $("#Etype").html(result[0].EmployeeType);
                $("#userdata").val(result[0].EmpId);
                $("#myModal").modal({ keyboard: true, show: 'true' });
                ProjectGrid();                
            }
        });
    });

    function assignButton(cellValue, options, rowdata, action) {        
        return '<a href=\'' + rowdata.EmpId + '\' data-toggle="modal"   class="btn btn-info assignlink " value=\'' + rowdata.EmpId + '\' >Assign</a>';        
    }
    var timeoutgridcomplete = 1000;
    $("#userGrids").jqGrid({
        url: '/Employee/GetUsers',
        datatype: 'json',
        mtype: 'get',
        colNames: ['First Name', 'Email ID', 'Employee Type', 'Status', 'Assign Project'],
        colModel: [
            {
                name: 'FirstName',
                index: 'FirstName',
                sortable: true,
                align: 'Center',                
                editable: true,
                edittype: 'text',
                search: false
            },
            {
                name: 'EmailId',
                index: 'EmailId',
                sortable: true,
                align: 'Center',                
                editable: true,
                edittype: 'text',
                search: false
            },
            {
                name: 'EmployeeType',
                index: 'EmployeeType',
                sortable: true,
                align: 'Center',                
                editable: true,
                edittype: 'text',
                search: false
            },
            {
                name: 'Status',
                index: 'Status',
                sortable: true,
                align: 'Center',                
                editable: true,
                edittype: 'text',
                search: false
            },

            {
                name: 'Assign',                
                align: 'Center',                
                editable: true,
                edittype: 'text',
                search: false,
                formatter: assignButton
            },            
        ],
       
        viewrecords: true,
        sortname: 'EmployeeId',
        sortorder: "Desc",
        height: 'auto',        
        rownumbers: true,
        caption: 'Employee',
        
        loadonce: false,
        width: null,      
        rowNum: 10,
        loadonce: false,
        rowList: [2, 5, 10, 15,20],
        pager: jQuery('#userPagination'),
        viewrecords: true,
        autowidth: true,
        shrinkToFit: true,
        search: true,
        page: function () { return 1; },
        gridComplete: function () {
            setTimeout(function () {
                
            }, timeoutgridcomplete);

        }

    });
    
});
