﻿$(document).ready(function () {
    // $('.text-box').addClass('form-control');

//    $('.alphaonly').bind('keyup blur', function () {
//        var TextReplace = $(this);
//        TextReplace.val(TextReplace.val().replace(/[^a-z]/g, ''));
//    }
//);

    $('.datepicker').datepicker({
        //        format: "dd/mm/yyyy",
        format: 'dd/mm/yyyy',
        autoclose: true,
    }).on('changeDate', function (ev) {
        $(this).datepicker('hide');
    });

  

    $("#Country").change(function () {
        $('#City').empty();
        //alert("hello");
        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: '/Employee/GetState',
            data: JSON.stringify({ countryName: $("#Country").val() }),
            dataType: "JSON ",
            success: function (data) {
                var result = JSON.parse(data);
                var items = '<option>--Select State--</option>';
                $.each(result, function (i, state) {
                    items += "<option value='" + state.Value + "'>" + state.Text + "</option>";
                });
                $('#State').html(items);
            },
            error: function (result) {
                $.notify(result, "error");
            }
        });
    });

    $("#State").change(function () {
        //alert("hello");
        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: '/Employee/GetCity',
            data: JSON.stringify({ StateName: $("#State").val() }),
            dataType: "JSON ",
            success: function (data) {
                var result = JSON.parse(data);
                var items = '<option>--Select City--</option>';
                $.each(result, function (i, state) {
                    items += "<option value='" + state.Value + "'>" + state.Text + "</option>";
                });
                $('#City').html(items);
            },
            error: function (result) {
                $.notify(result, "error");
            }
        });
    });
   

    $('#uplodedImage').change(function () {
        var ext = $('#uplodedImage').val().split('.').pop().toLowerCase();
        if ($.inArray(ext, ['png', 'jpg', 'jpeg']) == -1) {
            //alert('invalid extension!');
            $('#msg').html("Please Select Valid file(jpeg/png/jpg)");
            // return false;
        }
        else {
            $('#msg').html("");
            // return true;
        }

    });
    $('form').submit(function () {
        var ext = $('#uplodedImage').val().split('.').pop().toLowerCase();
        if (ext == null || ext == "")
            $('#msg').html("Please Select Valid file(jpeg/png/jpg)");
        // return false;
    });
});

