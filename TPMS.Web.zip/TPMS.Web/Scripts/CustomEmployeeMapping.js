﻿$(document).ready(function () {
    $('#Sucess-msg').empty();
    $('#Fail-msg').empty();
    $('#StartDate').val("");
    $('#EndDate').val("");
    var a = $('#userdata').val();
    //alert("empid=" + a);
    $('.btn').click(function () {
        var a = $('#userdata').val();
        /// alert("hi"+a);
    });
});

$('#closeModelBtn').click(function () {
    alert("close");
    $('#Sucess-msg').empty();
    $('#Fail-msg').empty();
});

function OnSuccess(response) {
    //alert(response + "onsucess");
    $('#Sucess-msg').html('Project Assign Successfully');
    $("#AssignProject").jqGrid().trigger('reloadGrid');
    $('#StartDate').val("");
    $('#EndDate').val("");
}

function OnFailure(response) {
    alert("Some thing went Wrong");
    $('#Fail-msg').html('Some thing went Wrong');
}


    $('.datepicker').datepicker({
        //        format: "dd/mm/yyyy",
        format: 'dd/mm/yyyy',                               
        autoclose: true
    }).on('changeDate', function (ev) {
        $(this).datepicker('hide');
    });
