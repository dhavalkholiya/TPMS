﻿$(document).ready(function () {

    $("#filtergrid").click(function () {
        filterGrid();
    });

    function filterGrid() {
        var postDataValues = $("#userGrids").jqGrid('getGridParam', 'postData');
        postDataValues['StartDate'] = $("#StartDate").val();
        postDataValues['Enddate'] = $("#EndDate").val();

        $("#userGrids").jqGrid().setGridParam({ postData: postDataValues, page: 1 }).trigger('reloadGrid');
    }


    $("#userGrids").jqGrid({
        colNames: ['Project Title', 'Description', 'Start Date', 'End Date', 'Completed Date', 'Status'],
        colModel: [
            {
                name: 'ProjectTitle',
                index: 'ProjectTitle',
                sortable: true,
                align: 'Center',
                
                editable: true,
                edittype: 'text',
                search: false
            },
            {
                name: 'Description',
                index: 'Description',
                sortable: true,
                align: 'Center',
                
                editable: true,
                edittype: 'text',
                search: false
            },
            {
                name: 'StartDate',
                index: 'StartDate',
                sortable: true,
                align: 'Center',
                
                editable: true,
                edittype: 'text',
                search: false,
                formatter: 'date'
            },
            {
                name: 'EndDate',
                index: 'EndDate',
                sortable: true,
                align: 'Center',
                
                editable: true,
                edittype: 'text',
                search: false,
                formatter: 'date'
            },
            {
                name: 'CompletedDate',
                index: 'CompletedDate',
                sortable: true,
                align: 'Center',
                
                editable: true,
                edittype: 'text',
                search: false,
                formatter: 'date'
            },
            {
                name: 'Status',
                sortable: true,
                align: 'Center',
                
                editable: true,
                edittype: 'text',
                search: false

            },

        ],
        pager: true,
        viewrecords: true,
        sortname: 'FirstName',
        sortorder: "Asc",
        height: 'auto',
        viewrecords: true,
        rownumbers: true,
        caption: 'InCompleted Projects In Time List',
        url: '/Employee/GetInCompletedProjectList',
        datatype: 'json',
        mtype: 'get',

        rowNum: 10,
        loadonce: false,
        rowList: [2, 5, 10, 15],
        pager: '#userPagination',
        viewrecords: true,
        autowidth: false,
        shrinkToFit: true,
        search: true
    });

});
