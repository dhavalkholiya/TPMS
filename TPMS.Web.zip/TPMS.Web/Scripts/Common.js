﻿$('.datepicker').datepicker({
    //        format: "dd/mm/yyyy",
    format: 'dd/mm/yyyy',
    autoclose: true
}).on('changeDate', function (ev) {
    $(this).datepicker('hide');
});