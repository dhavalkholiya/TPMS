﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using System.Web;

namespace TPMS.Model
{
    public class EmployeeModel
    {
        public int EmpId { get; set; }

        [Required(ErrorMessage="Please select Employee Type")]
        [Display(Name="Employee Type")]
        public string EmployeeType { get; set; }
        
        [Required(ErrorMessage = "Enter First Name")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Enter Only Alphabets")]       
        [Display(Name = "First Name")]
        public string FirstName { get; set; }
        
        [Required(ErrorMessage = "Enter Middle Name")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Enter Only Alphabets")]
        [Display(Name = "Middle Name")]
        public string MiddleName { get; set; }
        
        [Required(ErrorMessage = "Enter Last Name")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Enter Only Alphabets")]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Enter Email id")]
        [DataType(DataType.EmailAddress)]
        [EmailAddress(ErrorMessage = "Email Address is not valid")]
        [Remote("ValidateEmailId", "Employee", ErrorMessage = "Email Id Already Exist")]
        [Display(Name = "Email Id")]
        public string EmailId { get; set; }

        [Required(ErrorMessage = "Enter Password")]
        [StringLength(30, ErrorMessage = "{0} must be atleast {2} character long", MinimumLength = 6)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Enter Confirm Password")]
        
        [Display(Name = "confirm Password")]
        [System.Web.Mvc.Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }

        [Required(ErrorMessage = "Plz select Gender")]
        [Display(Name = "Gender")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "select Merital Status")]
        [Display(Name = "Merital Status")]
        public string MeritalStatus { get; set; }
                

        [Required(ErrorMessage = "select Profile Picture")]        
        [Display(Name = "Profile Picture")]
        public string PhotoName { get; set; }

        [Required(ErrorMessage = "plz select BloodGroup")]
        [Display(Name = "Blood Group")]
        public string BloodGroup { get; set; }

        [Required(ErrorMessage = "Enter Birth Date")]        
        [DataType(DataType.DateTime, ErrorMessage = "Invalid Date")]
        //[DataType(DataType.Date,ErrorMessage="Invalid date"), DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Birth Date")]
        [Remote("ValidateBirthDate", "Employee", ErrorMessage = "Email Id Already Exist")]
        [RegularExpression("(0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((19|20)\\d\\d)", ErrorMessage = "Enter valid date in that format dd/mm/yyyy")]        
        public String BirthDate { get; set; }

        [Required(ErrorMessage = "Enter Joining Date")]
        [DataType(DataType.DateTime, ErrorMessage = "Invalid Date")]
        [RegularExpression("(0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((19|20)\\d\\d)", ErrorMessage = "Enter valid date in that format dd/mm/yyyy")]
        [Display(Name = "Joining Date")]
        public String JoiningDate { get; set; }

        [Required(ErrorMessage = "Select Status")]
        [Display(Name = "Employee Status")]
        public string Status { get; set; }

        [Required(ErrorMessage = "Enter Address")]
        [Display(Name = "Address Line 1")]
        public string AddressLine1 { get; set; }

        [Display(Name = "Address Line 2")]
        public string AddressLine2 { get; set; }

        [Required(ErrorMessage = "Select Country")]
        [Display(Name = "Country")]
        public string Country { get; set; }

        [Required(ErrorMessage = "Select State")]
        [Display(Name = "State")]
        public string State { get; set; }
        
        [Required(ErrorMessage = "Select city")]
        [Display(Name = "City")]
        public string City { get; set; }
        
        [Required(ErrorMessage = "Enter Phone Number")]
        [StringLength(10, ErrorMessage = "{0} must be  {2} digit long", MinimumLength = 10)]        
        [RegularExpression("^[0-9]*$", ErrorMessage = "Phone No must be numeric")]
        [Display(Name = "Phone No")]
        public string PhoneNo { get; set; }

        [Required(ErrorMessage = "Enter ZipCode")]
        [StringLength(6, ErrorMessage = "{0} must be  {2} digit long", MinimumLength = 6)]
        [RegularExpression("^[0-9]*$", ErrorMessage = "ZipCode must be numeric")]
        [Display(Name = "ZipCode")]
        public string ZipCode { get; set; } 

    }
}
