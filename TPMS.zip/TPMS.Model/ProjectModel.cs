﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPMS.Model
{
   public class ProjectModel
    {
        public int ProjectId { get; set; }
        public String ProjectTitle { get; set; }
        public String Description { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public DateTime CompletedDate { get; set; }
        public String Status { get; set; }

    }
}
