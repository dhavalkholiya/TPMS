﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ErrorLogFramework.Web.Model
{
    public class ErrorLogModel
    {
        public string ErrorGUID { get; set; }
        public string ErrorURL { get; set; }
        public string ErrorMessage { get; set; }
        public string InnerException { get; set; }
        public string StackTrace { get; set; }
        public string TargetSite { get; set; }
        public string ErrorSource { get; set; }
        public string BrowserDetails { get; set; }
        public string CookiesDetails { get; set; }
        public string IPAddress { get; set; }
        public string UserSession { get; set; }
    }
    public class ErrorLogInsertViewModel
    {
        public Int64 ErrorLogID { get; set; }
        public string ErrorGUID { get; set; }
        
    }
}