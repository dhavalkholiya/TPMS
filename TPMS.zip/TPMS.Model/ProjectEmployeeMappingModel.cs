﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace TPMS.Model
{
    public class ProjectEmployeeMappingModel
    {
        public int ProjectId { get; set; }
        public int EmployeeId { get; set; }

        [Required(ErrorMessage = "The Start date is required")]
        [DataType(DataType.DateTime,ErrorMessage="Invalid Date")]        
        [RegularExpression("(0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((19|20)\\d\\d)", ErrorMessage = "Enter valid date in that format dd/mm/yyyy")]
        [Remote("CheckDateValidation", "Employee", AdditionalFields = "EndDate,ProjectId,EmployeeId", ErrorMessage = "You Have Already Assign Project In given Date Please Choose different Date ")]
        public String StartDate { get; set; }

        [Required(ErrorMessage = "The End date is required")]
        [DataType(DataType.DateTime, ErrorMessage = "Invalid Date")]        
        [RegularExpression("(0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((19|20)\\d\\d)", ErrorMessage = "Enter valid date in that format dd/mm/yyyy")]    
        [Remote("CheckDateValidation", "Employee", AdditionalFields = "StartDate,ProjectId,EmployeeId", ErrorMessage = "You Have Already Assign Project In given Date Please Choose different Date ")]
        public String EndDate { get; set; }
       
    }


}
