﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPMS.DAL;
using TPMS.Model;
using System.Web.Mvc;

namespace TPMS.BAL
{
    public class UserLoginBAL
    {
        #region Declaration
        UserLoginDAL userLoginDal = new UserLoginDAL();
        #endregion
        public int ValidateUserLogin(UserLoginModel user)
        {            
            return userLoginDal.ValidateUserLogin(user); 
        }        
    }
}
