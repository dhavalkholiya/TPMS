﻿using ErrorLogFramework.Web.DAL;
using ErrorLogFramework.Web.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ErrorLogFramework.Web.BAL
{
    public class ErrorLogBAL
    {
        #region DECLARATION
        ErrorLogDAL errorLogDAL;
        #endregion
        /// <summary>
        /// SaveErrorLog into database
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public List<ErrorLogInsertViewModel> SaveErrorLog(ErrorLogModel errorLogModel)
        {
            errorLogDAL = new ErrorLogDAL();
            List<ErrorLogInsertViewModel> errorLogInsertViewModel = new List<ErrorLogInsertViewModel>();
            errorLogInsertViewModel = errorLogDAL.SaveErrorLog(errorLogModel);
            return errorLogInsertViewModel;
        }
    }
}