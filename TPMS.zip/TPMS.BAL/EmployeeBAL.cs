﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPMS.Model;
using TPMS.DAL;
using System.Web.Mvc;

namespace TPMS.BAL
{
    public class EmployeeBAL
    {
        #region Declaration
        EmployeeDAL employeeDal = new EmployeeDAL();
        #endregion
        
        #region AddEmployee
        public int AddEmployee(EmployeeModel emp)
        {
            int r = employeeDal.AddEmployee(emp);
            return r;
        }
        #endregion
        
        #region GetCountryList
        public List<SelectListItem> GetCountry()
        {
            return employeeDal.GetCountry();
        }
        #endregion

        #region GetStateList
        public List<SelectListItem> GetState(string countryName)
        {
            return employeeDal.GetState(countryName);
        }
        #endregion

        #region GetCityList
        public List<SelectListItem> GetCity(string StateName)
        {
            return employeeDal.GetCity(StateName);
        }
        #endregion
        
        #region FilterEmployeeList
        public List<EmployeeModel> FilterGridList(string filterValue, string columnName, string sortOrder, out int noOfRecords, int currentPage = 1, int pageSize = 10)
        {
            noOfRecords = 0;            
            return employeeDal.FilterGridList(filterValue, columnName, sortOrder, out noOfRecords, currentPage, pageSize);
        }
        #endregion

        #region GetPopUPData
        public List<EmployeeModel> GetPopUpData(int Id)
        {
            return employeeDal.GetPopUpData(Id);
        }
        #endregion

        #region GetProjectlist
        public List<SelectListItem> GetProjectlist(int EmployeeId)
        {
            return employeeDal.GetProjectlist(EmployeeId);
        }
        #endregion

        #region ProjectEmployeeMapping
        public int ProjectEmployeeMapping(ProjectEmployeeMappingModel projectEmployeeMappingModel)
        {
            return employeeDal.ProjectEmployeeMapping(projectEmployeeMappingModel);
        }
        #endregion


        #region GetInCompletedProjectList
        public List<ProjectModel> GetInCompletedProjectList(string StartDate,String EndDate)
        {
            if (StartDate == null || StartDate == "")
            {
                StartDate = "01/01/1950";
            }
            if (EndDate == null || EndDate == "")
            {
                EndDate = "01/12/2050";
            }
            return employeeDal.GetInCompletedProjectList(Convert.ToDateTime( StartDate),Convert.ToDateTime(EndDate));
        }
        #endregion

        #region GetProjectListById
        public List<ProjectModel> GetProjectListById(int employeeId)
        {
            return employeeDal.GetProjectListById(employeeId);
        }
        #endregion

        public String CheckDateValidation(ProjectEmployeeMappingModel projectEmployeeMappingModel)
        {
            return   employeeDal.CheckDateValidation(projectEmployeeMappingModel);
        }

        #region VAlidateEmailid
        public int ValidateEmailId(String EmailId)
        {
            return employeeDal.ValidateEmailId(EmailId);
        }
        #endregion
    }
}
