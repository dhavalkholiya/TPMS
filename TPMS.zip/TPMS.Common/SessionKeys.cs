﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ErrorLogFramework.Web.Common
{
    public class SessionKeys
    {
        /// <summary>      
        /// </summary>    
        /// <summary>
        /// Auto generate usersession id
        /// </summary>
        public const string UserSessionId = "UserSessionId";
  
    }
}