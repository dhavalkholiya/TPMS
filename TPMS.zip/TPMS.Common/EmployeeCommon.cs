﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace TPMS.Common
{
    public class EmployeeCommon
    {
        #region GetEmployeeType
        public List<SelectListItem> GetEmployeeType()
        {
            List<SelectListItem> EmpType = new List<SelectListItem>();
            EmpType.Add(new SelectListItem
            {
                Text = "Developer",
                Value = "Developer"
            });
            EmpType.Add(new SelectListItem
            {
                Text = "Team Leader",
                Value = "Team Leader"
            });
            EmpType.Add(new SelectListItem
            {
                Text = "Project Manager",
                Value = "Project Manager"
            });

            return EmpType;
        }
        #endregion

        #region GetBloodGroupList
        public List<SelectListItem> GetBloodGroup()
        {
            List<SelectListItem> bloodGroup = new List<SelectListItem>();
            bloodGroup.Add(new SelectListItem { Text = "A +ve", Value = "A +ve" });
            bloodGroup.Add(new SelectListItem { Text = "B +ve", Value = "B +ve" });
            bloodGroup.Add(new SelectListItem { Text = "O +ve", Value = "O +ve" });
            bloodGroup.Add(new SelectListItem { Text = "A -ve", Value = "A -ve" });
            bloodGroup.Add(new SelectListItem { Text = "B -ve", Value = "B -ve" });
            bloodGroup.Add(new SelectListItem { Text = "O -ve", Value = "O -ve" });
            bloodGroup.Add(new SelectListItem { Text = "AB +ve", Value = "AB +ve" });
            bloodGroup.Add(new SelectListItem { Text = "AB -ve", Value = "AB -ve" });

            return bloodGroup;
        }
        #endregion

        #region GetEmployeeStatusList
        public List<SelectListItem> GetEmployeeStatus()
        {
            List<SelectListItem> EmpStatus = new List<SelectListItem>();
            EmpStatus.Add(new SelectListItem { Text = "Probation", Value = "Probation" });
            EmpStatus.Add(new SelectListItem { Text = "Confirmed", Value = "Confirmed" });
            return EmpStatus;
        }
        #endregion
    }
    

    #region DBConnectionString
    public static class ConnectionDB
    {
        public static string DBConn = ConfigurationManager.ConnectionStrings["DBConnectionString"] != null ? ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString : "";
    }
    #endregion
}
