﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPMS.Common;
using TPMS.Model;
using System.Web.Mvc;

namespace TPMS.DAL
{
    public class UserLoginDAL
    {
        #region Declaration
        public static string ConnectionString = ConnectionDB.DBConn;
        #endregion
        public int ValidateUserLogin(UserLoginModel user)
        {
            SqlConnection sqlConnection = new SqlConnection(ConnectionString);
            sqlConnection.Open();
            SqlCommand cmd = new SqlCommand("usp_ValidateLogin", sqlConnection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@EmailId", user.EmailId);
            cmd.Parameters.AddWithValue("@Password", user.Password);
            //int resultUser = Convert.ToInt16( cmd.ExecuteScalar());
            int resultUser=0;
            SqlDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                user.EmployeeType = rdr["EmployeeType"].ToString();
                resultUser++;
            }
            
            return resultUser;            
        }

    }
}
