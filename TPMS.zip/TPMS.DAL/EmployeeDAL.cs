﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using TPMS.Model;
using System.Web.Mvc;
using TPMS.Common;

namespace TPMS.DAL
{
    public class EmployeeDAL
    {
        #region Declaration
        public static string ConnectionString = ConnectionDB.DBConn;     
        #endregion

        #region AddEmployee
        public int AddEmployee(EmployeeModel employeeModel)
        {
            int resultEmployee;
            using (SqlConnection sqlConnection = new SqlConnection(ConnectionString))
            {
                sqlConnection.Open();
                using (SqlCommand cmd = new SqlCommand("usp_RegisterEmployee", sqlConnection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@FirstName", employeeModel.FirstName);
                    cmd.Parameters.AddWithValue("@MiddleName", employeeModel.MiddleName);
                    cmd.Parameters.AddWithValue("@LastName", employeeModel.LastName);
                    cmd.Parameters.AddWithValue("@EmployeeType", employeeModel.EmployeeType);
                    cmd.Parameters.AddWithValue("@Gender", employeeModel.Gender);
                    cmd.Parameters.AddWithValue("@EmailId", employeeModel.EmailId);
                    cmd.Parameters.AddWithValue("@Password", employeeModel.Password);
                    cmd.Parameters.AddWithValue("@MeritalStatus", employeeModel.MeritalStatus);
                    cmd.Parameters.AddWithValue("@ProfilePicName", employeeModel.PhotoName);
                    cmd.Parameters.AddWithValue("@BloodGroup", employeeModel.BloodGroup);
                    cmd.Parameters.AddWithValue("@BirthDate", Convert.ToDateTime( employeeModel.BirthDate));
                    cmd.Parameters.AddWithValue("@JoiningDate", Convert.ToDateTime(employeeModel.JoiningDate));
                    cmd.Parameters.AddWithValue("@Status", employeeModel.Status);
                    cmd.Parameters.AddWithValue("@AddressLine1", employeeModel.AddressLine1);
                    cmd.Parameters.AddWithValue("@AddressLine2", employeeModel.AddressLine2);
                    cmd.Parameters.AddWithValue("@CountryId", Convert.ToInt16(employeeModel.Country));
                    cmd.Parameters.AddWithValue("@StateId", Convert.ToInt16(employeeModel.State));
                    cmd.Parameters.AddWithValue("@CityId", Convert.ToInt16(employeeModel.City));
                    cmd.Parameters.AddWithValue("@PhoneNo", employeeModel.PhoneNo);
                    cmd.Parameters.AddWithValue("@ZipCode", employeeModel.ZipCode);
                    resultEmployee = cmd.ExecuteNonQuery();
                }
                sqlConnection.Close();
            }
            return resultEmployee;
        }
        #endregion

        #region GetCountryList
        public List<SelectListItem> GetCountry()
        {
            List<SelectListItem> CountryList = new List<SelectListItem>();
            using (SqlConnection sqlConnection = new SqlConnection(ConnectionString))
            {
                sqlConnection.Open();
                using (SqlCommand cmd = new SqlCommand("usp_GetCountry", sqlConnection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataReader rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {
                        CountryList.Add(new SelectListItem
                        {
                            Value = rdr["CountryId"].ToString(),
                            Text = rdr["Name"].ToString()
                        });
                    }

                }
            }
            return CountryList;
        }
        #endregion

        #region GetStateList
        public List<SelectListItem> GetState(string countryName)
        {
            List<SelectListItem> StateList = new List<SelectListItem>();
            using (SqlConnection sqlConnection = new SqlConnection(ConnectionString))
            {
                sqlConnection.Open();
                using (SqlCommand cmd = new SqlCommand("usp_GetState", sqlConnection))
                {
                    if (StateList.Count <= 0)
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@CountryId", Convert.ToInt16(countryName));
                        SqlDataReader rdr = cmd.ExecuteReader();

                        while (rdr.Read())
                        {
                            StateList.Add(new SelectListItem
                            {
                                Value = rdr["StateId"].ToString(),
                                Text = rdr["Name"].ToString()
                            });
                        }
                    }
                }
                sqlConnection.Close();
            }
            return StateList;
        }
        #endregion

        #region GetCityList
        public List<SelectListItem> GetCity(string StateName)
        {
            List<SelectListItem> CityList = new List<SelectListItem>();

            using (SqlConnection sqlConnection = new SqlConnection(ConnectionString))
            {
                sqlConnection.Open();
                using (SqlCommand cmd = new SqlCommand("usp_GetCity", sqlConnection))
                {
                    if (CityList.Count <= 0)
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@StateId", Convert.ToInt16(StateName));
                        SqlDataReader rdr1 = cmd.ExecuteReader();

                        while (rdr1.Read())
                        {
                            CityList.Add(new SelectListItem
                            {
                                Text = rdr1["Name"].ToString(),
                                Value = rdr1["CityId"].ToString()
                            });
                        }
                    }
                }
                sqlConnection.Close();
            }
            return CityList;
        }
        #endregion

        #region GetUserList
        public List<EmployeeModel> FilterGridList(string filterValue, string columnName, string sortOrder,  out int  noOfRecords, int currentPage, int pageSize)
        {
            List<EmployeeModel> employeeList = new List<EmployeeModel>();
            using (SqlConnection sqlConnection = new SqlConnection(ConnectionString))
            {

                using (SqlCommand cmd = new SqlCommand("usp_MyfilterGridTry", sqlConnection))
                {
                    sqlConnection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Search", filterValue);

                    cmd.Parameters.AddWithValue("@CurrentPage", currentPage);
                    cmd.Parameters.AddWithValue("@PageSize", pageSize);
                    cmd.Parameters.AddWithValue("@ColumnName", columnName);
                    cmd.Parameters.AddWithValue("@SortOrder", sortOrder);

                    SqlParameter paramOutPut = new SqlParameter("@noOfRecords", SqlDbType.Int);
                    paramOutPut.Size = 15;
                    paramOutPut.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(paramOutPut);                 

                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        var employeeModel = new EmployeeModel();
                        employeeModel.EmpId = Convert.ToInt16(rdr["EmployeeId"].ToString());
                        employeeModel.FirstName = rdr["FirstName"].ToString();
                        employeeModel.EmailId = rdr["EmailId"].ToString();
                        employeeModel.EmployeeType = rdr["EmployeeType"].ToString();
                        employeeModel.Status = rdr["Status"].ToString();
                        
                        employeeList.Add(employeeModel);
                    }
                    rdr.Close();
                    

                   
                    if (cmd.Parameters["@noOfRecords"].Value != DBNull.Value)
                        noOfRecords = Convert.ToInt32(cmd.Parameters["@noOfRecords"].Value);
                    else
                        noOfRecords = 0;
                    sqlConnection.Close();
                }
            }
            return employeeList;
        }
        #endregion

        #region GetPopUPData
        public List<EmployeeModel> GetPopUpData(int Id)
        {
            List<EmployeeModel> employeeList = new List<EmployeeModel>();
            using (SqlConnection sqlConnection = new SqlConnection(ConnectionString))
            {
                sqlConnection.Open();
                using (SqlCommand cmd = new SqlCommand("usp_GetEmployeeById", sqlConnection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@EmployeeId", Id);
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        var employeeModel = new EmployeeModel();
                        employeeModel.EmpId = Convert.ToInt16(rdr["EmployeeId"]);
                        employeeModel.FirstName = rdr["FirstName"].ToString();
                        employeeModel.MiddleName = rdr["MiddleName"].ToString();
                        employeeModel.LastName = rdr["LastName"].ToString();
                        employeeModel.EmployeeType = rdr["EmployeeType"].ToString();
                        employeeModel.Status = rdr["Status"].ToString();
                        employeeList.Add(employeeModel);
                    }
                }
                sqlConnection.Close();
            }
            return employeeList;
        }
        #endregion

        #region Projectlist
        public List<SelectListItem> GetProjectlist(int employeeId)
        {
            List<SelectListItem> Projectlist = new List<SelectListItem>();

            using (SqlConnection sqlConnection = new SqlConnection(ConnectionString))
            {
                sqlConnection.Open();
                using (SqlCommand cmd = new SqlCommand("usp_GetProjectList", sqlConnection))
                {
                    
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@EmployeeId",employeeId);
                    SqlDataReader rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {
                        Projectlist.Add(new SelectListItem
                        {
                            Text = rdr["ProjectTitle"].ToString(),
                            Value = rdr["ProjectId"].ToString()
                        });
                    }
                    sqlConnection.Close();

                }

            }
            return Projectlist;
        }
        #endregion

        #region ProjectEmployeeMapping
        public int ProjectEmployeeMapping(ProjectEmployeeMappingModel projectEmployeeMappingModel)
        {
            int result = 0;
           // CheckDateValidation(projectEmployeeMappingModel);
            using (SqlConnection sqlConnection = new SqlConnection(ConnectionString))
            {
                sqlConnection.Open();
                using (SqlCommand cmd = new SqlCommand("usp_EmployeeProjectMapping", sqlConnection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ProjectId", projectEmployeeMappingModel.ProjectId);
                    cmd.Parameters.AddWithValue("@EmployeeId", projectEmployeeMappingModel.EmployeeId);
                    cmd.Parameters.AddWithValue("@StartDate", Convert.ToDateTime(projectEmployeeMappingModel.StartDate));
                    cmd.Parameters.AddWithValue("@EndDate", Convert.ToDateTime(projectEmployeeMappingModel.EndDate));
                    result = cmd.ExecuteNonQuery();
                }
            }
            return result;
        }
        #endregion
       
        #region GetInCompletedProjectList
        public List<ProjectModel> GetInCompletedProjectList(DateTime StartDate,DateTime EndDate)
        {
            List<ProjectModel> projectList = new List<ProjectModel>();
            using (SqlConnection sqlConnection = new SqlConnection(ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("usp_GetInCompletedProjectList", sqlConnection))
                {
                    sqlConnection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;                    
                    if (StartDate == EndDate)
                    { }
                    else
                    {
                        cmd.Parameters.AddWithValue("@StartDate", StartDate);
                        cmd.Parameters.AddWithValue("@EndDate", EndDate);
                    }
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        var projectModel = new ProjectModel();
                        projectModel.ProjectId = Convert.ToInt16(rdr["ProjectId"].ToString());
                        projectModel.ProjectTitle = rdr["ProjectTitle"].ToString();
                        projectModel.Description = rdr["Description"].ToString();
                        projectModel.StartDate = Convert.ToDateTime(rdr["StartDate"]);
                        projectModel.EndDate = Convert.ToDateTime(rdr["EndDate"]);
                        
                        projectModel.Status = rdr["Status"].ToString();
                        if (projectModel.Status == "In Progress" || projectModel.Status == "Canceled")
                        {

                        }
                        else
                        {
                           projectModel.CompletedDate = Convert.ToDateTime(rdr["CompletedDate"]);
                        }
                        projectList.Add(projectModel);
                    }
                }
                sqlConnection.Close();

            }
            return projectList;
        }
        #endregion

        #region GetProjectListById
        public List<ProjectModel> GetProjectListById(int employeeId)
        {
            List<ProjectModel> projectList = new List<ProjectModel>();
            using (SqlConnection sqlConnection = new SqlConnection(ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("usp_GetProjectListById", sqlConnection))
                {
                    sqlConnection.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@EmployeeId", employeeId);
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        var projectModel = new ProjectModel();
                        projectModel.ProjectId = Convert.ToInt16(rdr["ProjectId"].ToString());
                        projectModel.ProjectTitle = rdr["ProjectTitle"].ToString();
                        //projectModel.Description = rdr["Description"].ToString();
                        projectModel.StartDate = Convert.ToDateTime(rdr["StartDate"]);
                        projectModel.EndDate = Convert.ToDateTime(rdr["EndDate"]);

                        projectModel.Status = rdr["Status"].ToString();
                        if (projectModel.Status == "In Progress" || projectModel.Status == "Canceled"|| projectModel.Status == "New")
                        {

                        }
                        else
                        {
                            projectModel.CompletedDate = Convert.ToDateTime(rdr["CompletedDate"]);
                        }
                        projectList.Add(projectModel);
                    }
                }
            }
            return projectList;
        }
        #endregion

        #region CheckDateValidation
        public String CheckDateValidation(ProjectEmployeeMappingModel projectEmployeeMappingModel)
        {
            String result = "Y";
            DateTime StartDate, EndDate;
            DateTime ProjectStartDate, ProjectEndDate;
            String EmpType="";
            int count = 0;
            ProjectStartDate = Convert.ToDateTime(projectEmployeeMappingModel.StartDate);
            ProjectEndDate = Convert.ToDateTime(projectEmployeeMappingModel.EndDate);
            using (SqlConnection sqlConnection = new SqlConnection(ConnectionString))
            {
                sqlConnection.Open();              
                using (SqlCommand cmd = new SqlCommand("usp_CheckDateValidation", sqlConnection))
                {
                    cmd.Parameters.AddWithValue("@EmployeeId",projectEmployeeMappingModel.EmployeeId);
                    cmd.CommandType = CommandType.StoredProcedure;
                     SqlDataReader rdr = cmd.ExecuteReader();
                     while (rdr.Read())
                     {
                         count++;
                         StartDate =Convert.ToDateTime(rdr["StartDate"]);
                         EndDate=Convert.ToDateTime(rdr["EndDate"]);
                         EmpType = rdr["EmployeeType"].ToString();
                         //if (Convert.ToDateTime( projectEmployeeMappingModel.StartDate) <= StartDate  && Convert.ToDateTime( projectEmployeeMappingModel.EndDate) >= StartDate)
                         if (ProjectStartDate >= StartDate && ProjectStartDate <= EndDate)
                         {
                            
                             if (EmpType == "Developer" && count>=1)
                             {
                                 result = "N";
                                 break;
                             }
                             else if (EmpType == "Team Leader" && count>=2)
                             {
                                 result = "N";
                                 break;
                             }
                             else if (EmpType == "Project Manager" && count >= 3)
                             {
                                 result = "N";
                                 break;
                             }
                         }
                         else if (ProjectEndDate >= StartDate && ProjectEndDate <= EndDate)
                         //else if (Convert.ToDateTime(projectEmployeeMappingModel.StartDate) <= EndDate && Convert.ToDateTime(projectEmployeeMappingModel.EndDate) >= EndDate)
                         {
                             if (EmpType == "Develope" && count >= 1)
                             {
                                 result = "N";
                                 break;
                             }
                             else if (EmpType == "Team Leader" && count >= 2)
                             {
                                 result = "N";
                                 break;
                             }
                             else if (EmpType == "Project Manager" && count >= 3)
                             {
                                 result = "N";
                                 break;
                             }
                         }
                     }                    
                }
                sqlConnection.Close();

            }
            return result;
        }
        #endregion

        #region Email Validation
        public int ValidateEmailId(String EmailId)
        {
            
            using (SqlConnection sqlConnection = new SqlConnection(ConnectionString))
            {
                int result=0;                
                sqlConnection.Open();
                using (SqlCommand cmd = new SqlCommand("usp_EmailIDValidate", sqlConnection))
                {
                    cmd.Parameters.AddWithValue("@EmailId", EmailId);
                    cmd.CommandType = CommandType.StoredProcedure;                    
                    result = Convert.ToInt16(  cmd.ExecuteScalar().ToString());                    
                }
                sqlConnection.Close();
                return result;
            }
        }
        #endregion
    }
}