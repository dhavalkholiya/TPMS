﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using ErrorLogFramework.Web.Model;
using System.Configuration;
using ErrorLogFramework.Web.Common;

namespace ErrorLogFramework.Web.DAL 
{
    public class ErrorLogDAL
    {
        #region Declaration
        public static string ConnectionString = ConnectionDB.DBConn;
        #endregion
        
        public ErrorLogDAL()
        {
        }

        #region Log Error

        public List<ErrorLogInsertViewModel> SaveErrorLog(ErrorLogModel errorLogModel)
        {
            List<ErrorLogInsertViewModel> errorLogInsertViewModel = new List<ErrorLogInsertViewModel>();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("usp_Global_SaveErrorLog", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@ErrorURL", SqlDbType.NVarChar, 2500)).Value =        errorLogModel.ErrorURL;
                    cmd.Parameters.Add(new SqlParameter("@ErrorMessage", SqlDbType.VarChar, 8000)).Value =    errorLogModel.ErrorMessage;
                    cmd.Parameters.Add(new SqlParameter("@InnerException", SqlDbType.VarChar, 8000)).Value =   errorLogModel.InnerException;
                    cmd.Parameters.Add(new SqlParameter("@StackTrace", SqlDbType.VarChar, 8000)).Value =         errorLogModel.StackTrace;
                    cmd.Parameters.Add(new SqlParameter("@TargetSite", SqlDbType.VarChar, 500)).Value =       errorLogModel.TargetSite;
                    cmd.Parameters.Add(new SqlParameter("@ErrorSource", SqlDbType.VarChar, 500)).Value =      errorLogModel.ErrorSource;
                    cmd.Parameters.Add(new SqlParameter("@BrowserDetails", SqlDbType.VarChar, 500)).Value =    errorLogModel.BrowserDetails;
                    cmd.Parameters.Add(new SqlParameter("@CookiesDetails", SqlDbType.VarChar, 500)).Value =    errorLogModel.CookiesDetails;
                    cmd.Parameters.Add(new SqlParameter("@IPAddress", SqlDbType.VarChar, 20)).Value =         errorLogModel.IPAddress;
                    cmd.Parameters.Add(new SqlParameter("@UserSession", SqlDbType.VarChar, 200)).Value =      errorLogModel.UserSession;

                    cmd.Connection.Open();

                    using (IDataReader dataReader = cmd.ExecuteReader())
                    {
                        errorLogInsertViewModel = Util.DataReaderMapToList<ErrorLogInsertViewModel>(dataReader);
                    }
                    con.Close();
                }
            }
            return errorLogInsertViewModel;
        }
        #endregion
    }
}